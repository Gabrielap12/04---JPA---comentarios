package br.com.faip.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "TB_PRODUTO") 
//NAME -> nome da sequencia no java (@generatedValue)
//SequenceName -> nome da sequencia no banco de dados
@SequenceGenerator(name="Produto", sequenceName="SQ_TB_PRODUTO", allocationSize = 1)
public class Produto {
	
	@Id
	@Column(name="CD_PRODUTO")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="Produto")
	private int codigo;
	
	@Column(name="NM_PRODUTO")
	private String nome;
	
	@Column(name="VL_PRODUTO")
	private double valor;
	
	@Transient // N�o ser� mapeado para base de dadps
	private double valorLiquido;
	
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	
	
}
